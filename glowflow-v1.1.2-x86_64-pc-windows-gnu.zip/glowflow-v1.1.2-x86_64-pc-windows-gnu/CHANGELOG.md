# Changelog

## v1.1.2

- Added first-class `build agent` syntax for compact webhook-based AI agents
- Added `support_bot_agent.glow` using webhook trigger, MCP filesystem, session memory, system prompt, and `reply result`
- Added focused parser/runtime/example coverage for the new `build agent` feature
- Added first-class `compress ... into ...` blocks with `target`, `mode`, `preserve`, `keep`, and `require`
- Added safe `auto target` mode for `compress`, with explicit advanced tuning inputs
- Upgraded structural compression from raw truncation to sentence/paragraph-aware retention with deterministic scoring
- Updated package metadata and public docs to the `v1.1.2` line

## v1.1.1

- Added advanced context-control built-ins:
  - `calculate tokens`
  - `jerina probability ... with ...`
  - `optimal allocation ... with ...`
  - `collapse ... to ...`
- Added a FastAPI telemetry companion in `telemetry/fastapi_proxy.py`
- Added a runnable advanced context-control GlowScript example
- Added focused regression coverage for the new built-ins and example

## v1.0.1

- Added HTTPS webhook serving with `glow serve ... --https --cert ... --key ...`
- Added language-level error handling with `try`, `catch`, `throw`, and postfix `recover`
- Added TLS configuration loading with beginner-readable diagnostics for missing or malformed certificate files
- Added new examples for error recovery, secure webhooks, and more robust automation flows
- Added focused `v1.0.1` regression tests on top of the retained mother end-to-end scenario
- Kept the interpreter/native parity proof path intact while extending the language surface

## v1.0.0

- First public release line for GlowFlow and GlowScript
- Plain-English automation language with parser, formatter, semantics, interpreter, CLI, and native build path
