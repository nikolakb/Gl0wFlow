# GlowFlow MCP for Gemini CLI

GlowFlow includes a stdio MCP server for Gemini CLI.

The command Gemini CLI should run is:

```bash
glow mcp-serve
```

This MCP server exposes GlowFlow-specific tools:

- `glow_check`
- `glow_run`
- `glow_format`
- `glow_inspect`
- `glow_build`
- `glow_new`

## Install

If `glow` is already installed at `~/.local/bin/glow`:

```bash
./gemini-cli/install-glowflow-mcp.sh
```

If `glow` lives elsewhere:

```bash
./gemini-cli/install-glowflow-mcp.sh /absolute/path/to/glow
```

The installer updates:

```text
~/.gemini/settings.json
```

with:

```json
{
  "mcpServers": {
    "glowflow": {
      "command": "/absolute/path/to/glow",
      "args": ["mcp-serve"]
    }
  }
}
```

## Manual setup

Use the template in:

- [`gemini-cli/settings.example.json`](/Users/nikolajeremic/Desktop/Gl0w/gemini-cli/settings.example.json)

or add the MCP server directly with Gemini CLI if your installed version supports MCP add commands.

## What it gives Gemini CLI

Once configured, Gemini CLI can:

- check a `.glow` file
- run a `.glow` file
- format a `.glow` file
- inspect a `.glow` AST
- build a `.glow` file
- scaffold a new GlowFlow project

This is intended as a GlowFlow tool bridge for Gemini CLI, not as a generic MCP transport layer for all future GlowFlow runtime adapters.
