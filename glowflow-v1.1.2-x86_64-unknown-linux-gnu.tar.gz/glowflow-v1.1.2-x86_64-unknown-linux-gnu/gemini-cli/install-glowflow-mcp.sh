#!/usr/bin/env bash
set -euo pipefail

GLOW_BIN="${1:-$HOME/.local/bin/glow}"
SETTINGS_DIR="${HOME}/.gemini"
SETTINGS_FILE="${SETTINGS_DIR}/settings.json"

mkdir -p "${SETTINGS_DIR}"

if [[ ! -x "${GLOW_BIN}" ]]; then
  echo "Glow binary not found or not executable at: ${GLOW_BIN}" >&2
  echo "Install GlowFlow first or pass the binary path explicitly." >&2
  exit 1
fi

SETTINGS_FILE_ENV="${SETTINGS_FILE}" GLOW_BIN_ENV="${GLOW_BIN}" python3 - <<'PY'
import json
import os
from pathlib import Path

settings_path = Path(os.environ["SETTINGS_FILE_ENV"])
glow_bin = os.environ["GLOW_BIN_ENV"]

if settings_path.exists():
    data = json.loads(settings_path.read_text())
else:
    data = {}

mcp = data.setdefault("mcpServers", {})
mcp["glowflow"] = {
    "command": glow_bin,
    "args": ["mcp-serve"],
}

settings_path.write_text(json.dumps(data, indent=2) + "\n")
print(f"Updated {settings_path}")
print("Configured Gemini CLI MCP server 'glowflow'.")
PY
